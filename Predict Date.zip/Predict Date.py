import pickle
import datetime as dt
import pandas as pd
import warnings

warnings.filterwarnings("ignore")

model = pickle.load(open('The Prediction model','rb'))

in_date = input("\nEnter In Date & Time (dd-mm-yy hh:mm:ss):")
con_size = int(input("Enter Container Size:"))
status = input("Enter Status (E/L):")


if status.upper()=="L":
    status=1
else:
    status=0
 
in_date = dt.datetime.strptime(in_date, '%d-%m-%y %H:%M:%S')

y_pred1 = model.predict([[con_size,status,
                          in_date.year,in_date.month,in_date.day,
                          in_date.hour,in_date.minute,in_date.second,
                          in_date.weekday(),
                          in_date.isocalendar().week,
                          pd.Timestamp(in_date).quarter]])

y_pred1 =  [ int(x.round()) for x in y_pred1[0]]

out_date = dt.date(y_pred1[0],y_pred1[1],y_pred1[2])

temp = dt.date(in_date.year,in_date.month,in_date.day)

if (temp>out_date):

    if in_date.hour > 15:
        temp = temp + dt.timedelta(days=1)

    if out_date.year>in_date.year:

        if out_date.month>in_date.month:

            if out_date.day>=in_date.day:
                pass

            else:
                out_date=temp
        else:
            out_date=temp

    else:
        out_date=temp

print("\nThe expected OUT_DATE of the container:",out_date)
