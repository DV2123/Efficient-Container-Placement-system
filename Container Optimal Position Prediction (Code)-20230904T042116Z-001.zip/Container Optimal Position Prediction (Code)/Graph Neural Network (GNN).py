import pandas as pd
import dgl
import numpy as np
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import torch
import torch.nn as nn
import dgl.function as fn
from dgl.nn import GraphConv

# Load and preprocess the data
yard_data = pd.read_csv('yard_data.csv')
container_data = pd.read_csv('container_data.csv')

# Data preprocessing
container_data['IN TIME'] = pd.to_datetime(container_data['IN TIME'])
container_data['OUT TIME'] = pd.to_datetime(container_data['OUT TIME'], errors='coerce')

merged_data = pd.merge(container_data, yard_data, how='left', left_on=['CON_SIZE', 'CON_NUM'], right_on=['Container Size', 'Location'])
merged_data['Stay Duration'] = (datetime.now() - merged_data['IN TIME']).dt.total_seconds()

# Feature Engineering
label_encoders = {}

categorical_features = ['Area', 'Bay', 'Location Status', 'STATUS']
for feature in categorical_features:
    le = LabelEncoder()
    merged_data[feature + '_encoded'] = le.fit_transform(merged_data[feature])
    label_encoders[feature] = le

features = ['Area_encoded', 'Row', 'Bay_encoded', 'Level', 'CON_SIZE', 'STATUS_encoded', 'Stay Duration']

# Create graph
container_nodes = merged_data.index.tolist()
edges = [(container_nodes.index(row), container_nodes.index(col)) for row, col in zip(merged_data['Container Size'], merged_data['Location'])]
graph = dgl.graph((np.array(edges)[:, 0], np.array(edges)[:, 1]), num_nodes=len(container_nodes))

# Convert graph and features to PyTorch tensors
g = dgl.to_homogeneous(graph)
features = torch.tensor(merged_data[features].values, dtype=torch.float32)
labels = torch.tensor(merged_data['Occupied'].values, dtype=torch.long)

# Split data into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(features, labels, test_size=0.2, random_state=42)
train_mask = torch.BoolTensor(X_train.index.isin(container_nodes))
val_mask = torch.BoolTensor(X_val.index.isin(container_nodes))

# Define a Graph Neural Network
class GNN(nn.Module):
    def __init__(self, in_feats, hidden_size, num_classes):
        super(GNN, self).__init__()
        self.conv1 = GraphConv(in_feats, hidden_size)
        self.conv2 = GraphConv(hidden_size, num_classes)

    def forward(self, g, features):
        x = torch.relu(self.conv1(g, features))
        x = self.conv2(g, x)
        return x

# Create model
model = GNN(in_feats=len(features[0]), hidden_size=64, num_classes=2)

# Loss function and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

# Training loop
for epoch in range(100):
    model.train()
    logits = model(g, features)
    loss = criterion(logits[train_mask], y_train[train_mask])

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

# Validation
model.eval()
with torch.no_grad():
    logits = model(g, features)
    predicted_labels = logits[val_mask].argmax(1)
    val_accuracy = accuracy_score(y_val[val_mask], predicted_labels)
    print(f"Validation Accuracy: {val_accuracy:.4f}")

# Predict optimal location for a new container
new_container_data = pd.DataFrame(...)  # Data for the new container
new_container_data['IN TIME'] = pd.to_datetime(new_container_data['IN TIME'])  # Convert date-time to datetime object
new_container_data['Stay Duration'] = (datetime.now() - new_container_data['IN TIME']).total_seconds()  # Calculate Stay Duration
for feature in categorical_features:
    le = label_encoders[feature]
    new_container_data[feature + '_encoded'] = le.transform(new_container_data[feature])
new_container_features = torch.tensor(new_container_data[features].values, dtype=torch.float32)

# Predict using the trained model
model.eval()
with torch.no_grad():
    new_container_logits = model(g, new_container_features)
    new_container_prediction = new_container_logits[0].argmax().item()

# Print optimal location prediction
if new_container_prediction == 0:  # If predicted as unoccupied
    optimal_location_index = new_container_data.index[0]
    optimal_location = merged_data['Location'].iloc[optimal_location_index]
    print(f"Optimal location for the new container: {optimal_location}")
else:
    print("No optimal location available for the new container.")
