import pandas as pd
from datetime import datetime
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Load and preprocess the data
yard_data = pd.read_csv('yard_data.csv')
container_data = pd.read_csv('container_data.csv')

# Data preprocessing
# Convert date-time strings to datetime objects
container_data['IN TIME'] = pd.to_datetime(container_data['IN TIME'])
container_data['OUT TIME'] = pd.to_datetime(container_data['OUT TIME'], errors='coerce')

# Merge container_data and yard_data based on common attributes
merged_data = pd.merge(container_data, yard_data, how='left', left_on=['CON_SIZE', 'CON_NUM'], right_on=['Container Size', 'Location'])

# Encode categorical features
label_encoders = {}  # Store label encoders for future use

categorical_features = ['Area', 'Bay', 'Location Status', 'STATUS']
for feature in categorical_features:
    le = LabelEncoder()
    merged_data[feature + '_encoded'] = le.fit_transform(merged_data[feature])
    label_encoders[feature] = le

# Feature selection for modeling
features = ['Area_encoded', 'Row', 'Bay_encoded', 'Level', 'CON_SIZE', 'STATUS_encoded']
X = merged_data[features]

# Calculate Stay Duration
now = datetime.now()
merged_data['Stay Duration'] = (now - merged_data['IN TIME']).dt.total_seconds()

y = merged_data['Occupied']

# Split data into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Random Forest Classifier
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Make predictions on the validation set
y_pred = model.predict(X_val)

# Evaluate the model's performance
accuracy = accuracy_score(y_val, y_pred)
print(f"Accuracy: {accuracy:.2f}")

# When a new container arrives, use the trained model to predict the optimal location
new_container_data = pd.DataFrame(...)  # Data for the new container
new_container_data['IN TIME'] = pd.to_datetime(new_container_data['IN TIME'])  # Convert date-time to datetime object
new_container_data['Stay Duration'] = (now - new_container_data['IN TIME']).dt.total_seconds()  # Calculate Stay Duration
for feature in categorical_features:
    le = label_encoders[feature]
    new_container_data[feature + '_encoded'] = le.transform(new_container_data[feature])
new_container_features = ['Area_encoded', 'Row', 'Bay_encoded', 'Level', 'CON_SIZE', 'STATUS_encoded', 'Stay Duration']
new_container_pred = model.predict(new_container_data[new_container_features])
if new_container_pred == 0:  # If predicted as unoccupied
    optimal_location = new_container_data['Location'].iloc[0]
    print(f"Optimal location for the new container: {optimal_location}")
else:
    print("No optimal location available for the new container.")
