import pandas as pd
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import LabelEncoder

# Load and preprocess the data
yard_data = pd.read_csv('yard_data.csv')
container_data = pd.read_csv('container_data.csv')

# Data preprocessing
container_data['IN TIME'] = pd.to_datetime(container_data['IN TIME'])
container_data['OUT TIME'] = pd.to_datetime(container_data['OUT TIME'], errors='coerce')

merged_data = pd.merge(container_data, yard_data, how='left', left_on=['CON_SIZE', 'CON_NUM'],
                       right_on=['Container Size', 'Location'])
merged_data['Stay Duration'] = (datetime.now() - merged_data['IN TIME']).dt.total_seconds()

# Feature Engineering
label_encoders = {}

categorical_features = ['Area', 'Bay', 'Location Status', 'STATUS']
for feature in categorical_features:
    le = LabelEncoder()
    merged_data[feature + '_encoded'] = le.fit_transform(merged_data[feature])
    label_encoders[feature] = le

features = ['Area_encoded', 'Row', 'Bay_encoded', 'Level', 'CON_SIZE', 'STATUS_encoded', 'Stay Duration']

# Split data into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(merged_data[features], merged_data['Occupied'], test_size=0.2,
                                                  random_state=42)


# Define a Neural Network
class NeuralNet(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(NeuralNet, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x


# Instantiate the Neural Network model
input_size = len(features)
hidden_size = 64
output_size = 2  # Binary classification (occupied or not)
model = NeuralNet(input_size, hidden_size, output_size)

# Loss function and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

# Training loop
num_epochs = 100
for epoch in range(num_epochs):
    model.train()
    optimizer.zero_grad()
    outputs = model(X_train)
    loss = criterion(outputs, y_train)
    loss.backward()
    optimizer.step()

# Validation
model.eval()
with torch.no_grad():
    val_outputs = model(X_val)
    _, val_preds = torch.max(val_outputs, 1)
    val_accuracy = accuracy_score(y_val, val_preds)
    print(f"Validation Accuracy: {val_accuracy:.4f}")

# When a new container arrives, use the trained model to predict the optimal location
new_container_data = pd.DataFrame(...)  # Data for the new container
for feature in categorical_features:
    le = label_encoders[feature]
    new_container_data[feature + '_encoded'] = le.transform(new_container_data[feature])
new_container_features = new_container_data[features]

# Predict using the trained model
model.eval()
with torch.no_grad():
    new_container_outputs = model(new_container_features)
    _, new_container_prediction = torch.max(new_container_outputs, 1)

# Print optimal location prediction
if new_container_prediction == 0:  # If predicted as unoccupied
    optimal_location = new_container_data['Location'].iloc[0]
    print(f"Optimal location for the new container: {optimal_location}")
else:
    print("No optimal location available for the new container.")
